﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

/*
 Разработать программу, реализующую работу с коллекциями.
1.	Программа должна быть разработана в виде консольного приложения на языке C#.
2.	Создать объекты классов «Прямоугольник», «Квадрат», «Круг».
3.	Для реализации возможности сортировки геометрических фигур для класса 
«Геометрическая фигура» добавить реализацию интерфейса IComparable. 
Сортировка производится по площади фигуры.
4.	Создать коллекцию класса ArrayList. Сохранить объекты в коллекцию. 
Отсортировать коллекцию. Вывести в цикле содержимое коллекции. 
5.	Создать коллекцию класса List<Figure>. Сохранить объекты в коллекцию. 
Отсортировать коллекцию. Вывести в цикле содержимое коллекции.
6.	Модифицировать класс разреженной матрицы (проект SparseMatrix) для работы 
с тремя измерениями – x,y,z. Вывод элементов в методе ToString() осуществлять в том виде,
который Вы считаете наиболее удобным. Разработать пример использования 
разреженной матрицы для геометрических фигур.
7.	Реализовать класс «SimpleStack» на основе односвязного списка. 
Класс SimpleStack наследуется от класса SimpleList (разобранного в пособии). 
Необходимо добавить в класс методы:
•	public void Push(T element) – добавление в стек;
•	public T Pop() – чтение с удалением из стека.
8.	Пример работы класса SimpleStack реализовать на основе геометрических фигур.

     */

namespace Figures
{
    class Program
    {
        static void Main(string[] args)
        {
            Rect rect = new Rect(6, 4);
            Square square = new Square(5);
            Circle circle = new Circle(7);

            // ArrayList

            Console.WriteLine("\nArrayList");
            ArrayList arrayList = new ArrayList();
            arrayList.Add(circle);
            arrayList.Add(rect);
            arrayList.Add(square);

            foreach (var x in arrayList) Console.WriteLine(x);

            Console.WriteLine("\nArrayList - отсортированный");
            arrayList.Sort();

            foreach (var x in arrayList) Console.WriteLine(x);

            // List<Figure>

            Console.WriteLine("\nList<AbstractFigure>");
            List<AbstractFigure> figureList = new List<AbstractFigure>();
            figureList.Add(circle);
            figureList.Add(rect);
            figureList.Add(square);

            foreach (var x in figureList) Console.WriteLine(x);

            Console.WriteLine("\nList<AbstractFigure> - отсортированный");
            arrayList.Sort();

            foreach (var x in arrayList) Console.WriteLine(x);

            // Matrix<Figure>

            Console.WriteLine("\nMatrix<AbstractFigure>");
            Matrix<AbstractFigure> matrix = new Matrix<AbstractFigure>(2, 2, 2, rect);
            Console.WriteLine(matrix.ToString());

            // SimpleList<AbstractFigure>

            Console.WriteLine("SimpleList<AbstractFigure>");
            SimpleList<AbstractFigure> list = new SimpleList<AbstractFigure>();
            list.Add(square);
            list.Add(rect);
            list.Add(circle);

            foreach (var x in list) Console.WriteLine(x);

            Console.WriteLine("\nSimpleList<AbstractFigure> - отсортированный");
            list.Sort();

            foreach (var x in list) Console.WriteLine(x);

            // SimpleStack<AbstractFigure>

            Console.WriteLine("\nSimpleStack<AbstractFigure>");
            SimpleStack<AbstractFigure> stack = new SimpleStack<AbstractFigure>();
            stack.Push(rect);
            stack.Push(square);
            stack.Push(circle);

            while (stack.Count > 0)
            {
                AbstractFigure f = stack.Pop();
                Console.WriteLine(f);
            }

            Console.ReadKey();

        }
    }
}
